package ch2_2;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class c = new Class();
		System.out.println("-------Class's begin!-------");
		c.on();
		System.out.println("-------Class's over!-------");
		c.off();
	}

}
