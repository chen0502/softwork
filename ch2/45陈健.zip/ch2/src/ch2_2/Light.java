package ch2_2;

public class Light {
	public void on() {
		System.out.println("Open light");
	}

	public void off() {
		System.out.println("Close light");
	}
}
