package ch2_2;

public class Projector {
	public void on() {
		System.out.println("Open projector");
	}

	public void off() {
		System.out.println("Close projector");
	}
}
