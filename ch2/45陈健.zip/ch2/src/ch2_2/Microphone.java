package ch2_2;

public class Microphone {
	public void on() {
		System.out.println("Open microphone");
	}

	public void off() {
		System.out.println("Close microphone");
	}
}
