package ch2_2;

public class Curtain {
	public void on() {
		System.out.println("Open curtain");
	}

	public void off() {
		System.out.println("Close curtain");
	}
}
