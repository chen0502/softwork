package ch2_2;

public class Computer {
	public void on() {
		System.out.println("Open computer");
	}

	public void off() {
		System.out.println("Close computer");
	}
}
