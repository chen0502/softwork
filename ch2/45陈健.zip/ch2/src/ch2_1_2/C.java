package ch2_1_2;

public class C {

	public String zipcode(int code[]) {
		return "CLocation";
	}
}
