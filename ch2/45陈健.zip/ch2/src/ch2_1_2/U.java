package ch2_1_2;

public class U {
	public String findzipcode(String zipcode) {
		return "ULocation";
	}
}
