package ch2_1_1;

public class C {

	public String zipcode(int code[]) {
		return "CLocation";
	}
}
