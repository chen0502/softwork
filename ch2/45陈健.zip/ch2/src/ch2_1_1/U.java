package ch2_1_1;

public interface U {
	public String findzipcode(String zipcode);
}
