package ch3_2;

public class L extends Sys{

	@Override
	public void look() {
		String sys ="Linux";
		this.f.beread(sys);
		
	}

}
