package ch3_2;

public class GIF implements Fo {

	public void beread(String sys) {
		System.out.println(sys+"�鿴"+this.getClass());
	}

}
