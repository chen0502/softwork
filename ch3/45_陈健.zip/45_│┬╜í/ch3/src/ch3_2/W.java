package ch3_2;

public class W extends Sys {

	@Override
	public void look() {
		String sys = "Windows";
		this.f.beread(sys);
		
	}

}
