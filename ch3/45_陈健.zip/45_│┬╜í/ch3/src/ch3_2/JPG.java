package ch3_2;

public class JPG implements Fo {

	public void beread(String sys) {
		System.out.println(sys+"�鿴"+this.getClass());
		
	}

}
