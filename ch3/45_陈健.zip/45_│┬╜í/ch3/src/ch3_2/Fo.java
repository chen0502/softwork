package ch3_2;

public interface Fo {
 public void beread(String sys);
}
