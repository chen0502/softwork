package ch3_2;

public abstract class Sys {
 protected Fo f;

public void setF(Fo f) {
	this.f = f;
}
 public abstract void look(); 
}
